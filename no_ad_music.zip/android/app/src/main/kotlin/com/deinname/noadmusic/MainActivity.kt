package com.deinname.noadmusic

import com.ryanheise.audioservice.AudioServiceActivity

class MainActivity : AudioServiceActivity()
